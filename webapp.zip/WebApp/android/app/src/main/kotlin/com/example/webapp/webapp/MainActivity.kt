package com.example.webapp.webapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
