import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:webapp/models/image_model.dart';

class ApiService {
  final String apiKey = '43647136-108d6beb5a13567b0c7be0573';

  Future<List<ImageModel>> fetchImages({String query = '', int page = 1}) async {
      final response = await http.get(Uri.parse(
          'https://pixabay.com/api/?key=$apiKey&q=${Uri.encodeQueryComponent(query)}&image_type=photo&page=$page'));
      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body)['hits'];
        return jsonData.map((item) => ImageModel.fromJson(item)).toList();
      } else {
        throw Exception('Failed to load images');
      }

  }
}
