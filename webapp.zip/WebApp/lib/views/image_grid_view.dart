import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:webapp/views/search_bar_view.dart';
import '../controllers/image_controller.dart';
import '../models/image_model.dart';
import 'full_screen_image_view.dart';

class ImageGridView extends StatelessWidget {
  final ImageController imageController = Get.find();
  final ScrollController _scrollController = ScrollController();

  ImageGridView({super.key});

  @override
  Widget build(BuildContext context) {
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        // Load more images when scrolled to the bottom
        imageController.fetchImages();
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Gallery'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            SearchBarView(),
            Expanded( // Wrap the GridView with Expanded
              child: Obx(() {
                return GridView.builder(
                  shrinkWrap: true,
                  controller: _scrollController,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: _calculateColumnCount(
                        MediaQuery.of(context).size.width),
                    crossAxisSpacing: 8.0,
                    mainAxisSpacing: 8.0,
                    childAspectRatio: 1,
                  ),
                  itemCount: imageController.images.length + 1,
                  itemBuilder: (context, index) {
                    if (index < imageController.images.length) {
                      ImageModel image = imageController.images[index];
                      return GestureDetector(
                        onTap: () {
                          Get.to(() => FullScreenImageView(image: image),
                              transition: Transition.zoom);
                        },
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            children: [
                              Expanded( // Wrap the Image with Expanded
                                child: ClipRRect(
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(10.0),
                                    topRight: Radius.circular(10.0),
                                  ),
                                  child: Image.network(
                                    image.largeImageURL,
                                    fit: BoxFit.cover,
                                    width: double.infinity,
                                    height: _calculateHeight(
                                        MediaQuery.of(context).size.width),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        const FittedBox(
                                          fit: BoxFit.fitWidth,
                                          child: Icon(
                                            Icons.favorite,
                                            color: Colors.red,
                                          ),
                                        ),
                                        const SizedBox(width: 4.0),
                                        FittedBox(
                                          fit: BoxFit.fitWidth,
                                          child: Text('${image.likes}'),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        const FittedBox(
                                          fit: BoxFit.fitWidth,
                                          child: Icon(
                                            Icons.visibility,
                                          ),
                                        ),
                                        const SizedBox(width: 4.0),
                                        FittedBox(
                                          fit: BoxFit.fitWidth,
                                          child: Text('${image.views}',),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    } else {
                      // Loading indicator
                      return Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(16.0),
                        child: const CircularProgressIndicator(),
                      );
                    }
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  int _calculateColumnCount(double screenWidth) {
    return screenWidth < 600
        ? 3
        : screenWidth < 800
        ? 4
        : 5;
  }

  double _calculateHeight(double screenWidth) {
    return screenWidth < 600
        ? screenWidth * 0.22
        : screenWidth < 800
        ? screenWidth * 0.18
        : screenWidth * 0.14;
  }
}
