import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/image_controller.dart';

class SearchBarView extends StatelessWidget {
  final ImageController imageController = Get.find();

  SearchBarView({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        onChanged: (value) {
          imageController.updateQuery(value);
        },
        decoration: const InputDecoration(
          hintText: 'Search...',
          prefixIcon: Icon(Icons.search),
          border: OutlineInputBorder(),
        ),
      ),
    );
  }
}
