import 'package:get/get.dart';
import '../models/image_model.dart';
import '../services/api_service.dart';
import 'dart:developer' as developer;

class ImageController extends GetxController {
  final ApiService _apiService = ApiService();

  var images = <ImageModel>[].obs;
  var query = ''.obs;
  var page = 1.obs; // Track the current page for pagination
  var isLoading = false.obs; // Track if images are currently being loaded


  @override
  void onInit() {
    fetchImages();
    super.onInit();
  }

  void fetchImages() async {
    if (isLoading.value) return; // Prevent duplicate fetch requests
    isLoading.value = true;

    try {
      var fetchedImages = await _apiService.fetchImages(
        query: query.value,
        page: page.value,
      );
      images.addAll(fetchedImages);
      page.value++; // Increment page for next pagination
    } catch (e) {
      developer.log(e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  void updateQuery(String value) {
    query.value = value;
    images.clear(); // Clear existing images when search query changes
    page.value = 1; // Reset page to 1 for new search query
    fetchImages();
  }
}
