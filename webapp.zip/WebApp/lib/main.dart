import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:webapp/controllers/image_controller.dart';
import 'package:webapp/views/image_grid_view.dart';

void main() {

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final ImageController imageController = Get.put(ImageController());

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
        builder: (context, constraints) {
          return GetMaterialApp(
          title: 'Image Gallery',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          home: ImageGridView(),
        );
      }
    );
  }
}